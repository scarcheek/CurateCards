InFormal Style

Copyright�

Version: 1.0

Author: Nerio Perez

Email: a2nerio@gmail.com




Free for personal and commercial use.

For any suggestion write to the author�s email.

Your donations will help to maintain and improve this font:

https://www.paypal.me/a2nerio